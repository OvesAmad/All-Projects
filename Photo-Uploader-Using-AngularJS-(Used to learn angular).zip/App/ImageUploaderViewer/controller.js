var myApp = angular.module('app', []);

myApp.directive('fileInput', function($parse){
    return{
        restrict:'A',
        
        link: function(scope,element,attrs){
            var model = $parse(attrs.fileInput),
             modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope,element[0].files[0]);
                });
            });
        }
    };
});

myApp.service('fileUploadService', function($http){
    
    
   this.uploadFileToUrl = function($scope,label,file, uploadUrl){
       var fileFormData = new FormData();
       console.log(angular.isString(label));
       fileFormData.append('file', file);
       fileFormData.append('label', label);
       
       $http.post(uploadUrl, fileFormData,{
           tranformRequest: angular.identity,
           headers: {'Content-Type': undefined}
       }).success(function(response){
           $scope.select();
           alert(response);
       }).error(function(response){
           alert(response);
       });
   } 
});

myApp.controller('FileUploadController', function($scope, fileUploadService,$http){
    console.log("entered controller");
    $scope.uploadFile = function(){
        var file = $scope.myFile;
        var label = $scope.label;
        
        console.log(label);
        var uploadUrl = "service.php",
            promise = fileUploadService.uploadFileToUrl($scope,label,file,uploadUrl);
        promise.then(function(response){
            $scope.serverResponse = response;
            
        }, function(){
            $scope.serverResponse = 'An error has occured';
        })
    }
    $scope.select = function(){
        $http.get("select.php")
            .success(function(data){
            console.log(data);
            $scope.images = data;
        });
    }
});

