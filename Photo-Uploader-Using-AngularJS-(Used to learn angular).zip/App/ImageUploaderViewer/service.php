<?php
    $connect = mysqli_connect("localhost", "root", "", "testing");

if(!empty($_FILES) && count($_FILES) == 1){
    $label =$_POST['label'];
    $file_name = $_FILES['file']['name'];
    $path = 'upload/' . $file_name;
    
    if(move_uploaded_file($_FILES['file']['tmp_name'],$path)){
        $insertQuery = "INSERT INTO tbl_images(name,label) VALUES ('".$file_name."','".$label."')";
        
        if(mysqli_query($connect, $insertQuery)){
            echo 'File Uploaded and saved';
        }else{
            echo 'File not saved';
        }
    }

}else{
    echo 'No file selected';
}

?>