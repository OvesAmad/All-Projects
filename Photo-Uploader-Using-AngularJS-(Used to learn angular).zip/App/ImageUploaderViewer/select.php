<?php

$connect = mysqli_connect("localhost", "root","","testing");
$output = array();
$selectQuery = "SELECT * FROM tbl_images";
$result = mysqli_query($connect,$selectQuery);
while($row = mysqli_fetch_array($result)){
    $output[] = $row;
}
echo json_encode($output);

?>