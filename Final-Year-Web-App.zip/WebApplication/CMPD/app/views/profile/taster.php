<?php
	if($this->session->flashdata('selected')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('selected'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('error')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>
<h1>Apply for a taster</h1>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class= "form-group">
	<?php $attributes = array('id' => 'taster_form',
							  'class' => 'form-horizontal'); ?>
	<?php echo form_open('taster', $attributes); ?>

</div>
<div class= "form-group">
	<p>
		<?php echo form_label('English:*'); ?>
		<?php
			$data = array('A' => 'A',
						'B' => 'B',
						'C' => 'C',
						'D' => 'D',
						'E' => 'E',
						'F' => 'F');
			
		?>
		<?php echo form_dropdown('english',$data); ?>
	</p>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Maths:*'); ?>
		<?php
			$data = array('A' => 'A',
						'B' => 'B',
						'C' => 'C',
						'D' => 'D',
						'E' => 'E',
						'F' => 'F');
			
		?>
		<?php echo form_dropdown('maths',$data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Science:*'); ?>
		<?php
			$data = array('A' => 'A',
						'B' => 'B',
						'C' => 'C',
						'D' => 'D',
						'E' => 'E',
						'F' => 'F');
			
		?>
		<?php echo form_dropdown('science',$data); ?>
	</p>
</div>
<h2>Enter A level grade </h2>
<div class= "form-group">
	<p>
		<?php echo form_label('ICT:*'); ?>
		<?php
			$data = array('A' => 'A - Distinction',
						'B' => 'B - Merit',
						'C' => 'C - Pass',
						'D' => 'D - Fail');
			
		?>
		<?php echo form_dropdown('ict',$data); ?>
	</p>
</div>
<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>

<h3>Choose a taster day to attend</h3>
<table class = "table table-striped" width="50%" cellspacing="5" cellpadding="5">
	<tr>
		<th>Taster Date</th>
		<th>Taster Venue</th>
		<th></th>
	</tr>
	<?php if(isset($taster_days)) :?>
	<?php foreach($taster_days as $tdays) :?>
		<tr>
			<td> <?php echo $tdays->date; ?> </td>
			<td> <?php echo $tdays->venue; ?> </td>
			<td><a href="<?php echo base_url();?>taster/select/<?php echo $tdays->taster_id ;?>">Select</a></td>
		</tr>
	<?php endforeach; ?>
	<?php endif; ?>
</table>