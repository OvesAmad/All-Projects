<?php
	if($this->session->flashdata('error')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('create_app_failed')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('create_app_failed'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('login_success')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('login_success'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('profile_updated')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('profile_updated'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('profile_failed')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('profile_failed'); ?></p>
<?php endif; ?>


<h1>Your Profile</h1>
<?php foreach($profile as $profile) : ?>

<p><b>Name:</b></p><?php echo $profile->firstname;?>
	<?php echo $profile->lastname."</br>";?>
</br>

<p><b>Address:</b></p>	<?php echo $profile->housenum;?>
	<?php echo $profile->streetname."</br>"; ?>
	<?php echo $profile->postcode."</br>";?>
</br>

<p><b>Email:</b></p><?php echo $profile->email."</br>";?>
</br>

<p><b>Phone Number:</b></p><?php echo $profile->phonenumber;?>
</br>
<?php endforeach; ?>