<?php foreach($user_profile as $user_profile) : ?>

	<?php $housenum= $user_profile->housenum; ?>
	<?php $streetname=$user_profile->streetname; ?>
	<?php $postcode=$user_profile->postcode;?>
	<?php $email=$user_profile->email;?>
	<?php $phonenumber=$user_profile->phonenumber;?>

<?php endforeach; ?>


<h1>Edit your details</h1>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class= "form-group">
	<?php $attributes = array('id' => 'edit_form',
							  'class' => 'form-horizontal'); ?>
	<?php echo form_open('edit', $attributes); ?>

</div>
<div class= "form-group">
	<p>
		<?php echo form_label('House Number:*'); ?>
		<?php
			$data = array(
				'name' => 'housenum',
				'placeholder' => $user_profile->housenum,
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value($housenum)
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Street Name:*'); ?>
		<?php
			$data = array(
				'name' => 'streetname',
				'placeholder' => $streetname,
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value($streetname)
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Post Code:*'); ?>
		<?php
			$data = array(
				'name' => 'postcode',
				'placeholder' => $postcode,
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value($postcode)
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Telephone Number:*'); ?>
		<?php
			$data = array(
				'name' => 'telephone',
				'placeholder' => $phonenumber,
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value($phonenumber)
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Email:*'); ?>
		<?php
			$data = array(
				'name' => 'email',
				'placeholder' => $email,
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('email')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>
