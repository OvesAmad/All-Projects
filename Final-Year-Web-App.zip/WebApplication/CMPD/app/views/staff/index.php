<?php
	if($this->session->flashdata('login_success')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('login_success'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('profile_updated')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('profile_updated'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('profile_failed')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('profile_failed'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('scheduled')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('scheduled'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('not_scheduled')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('not_scheduled'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('deleteSuccess')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('deleteSuccess'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('deleteFailed')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('deleteFailed'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('editSuccess')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('editSuccess'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('editFailed')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('editFailed'); ?></p>
<?php endif; ?>
<h1>Your Profile</h1>
<?php foreach($profile as $profile) : ?>
<p><b>Name:</b></p><?php echo $profile->firstname;?>
	<?php echo $profile->lastname."</br>";?>
</br>

<p><b>Email:</b></p><?php echo $profile->email."</br>";?>
</br>

<p><b>Phone Number:</b></p><?php echo $profile->phone_number;?>
</br>
<?php endforeach; ?>