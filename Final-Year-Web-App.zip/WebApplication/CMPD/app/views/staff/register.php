<?php
	if($this->session->flashdata('registered')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('registered'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('error')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>
<h1>Register a member of staff</h1>
<h2>Fill in all fields</h2>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class = "form-group">
	<?php $attributes = array('id'=>'register_form',
								'class' => 'form-horizontal'); ?>
	<?php echo form_open('StaffCreate', $attributes); ?>
</div>

<h3>Personal Details</h3>
<div class="form-group">
	<p>
		<?php echo form_label('Staff class:*'); ?>
		<?php
			$data = array('1' => '1-Admin',
						'2' => '2-Staff',
						'3' => '3-Co-ordinator');
			
		?>
		<?php echo form_dropdown('class',$data); ?>
	</p>
</diV>

<div class="form-group">
	<p>
		<?php echo form_label('Firstname:*'); ?>
		<?php
			$data = array(
				'name' => 'firstname',
				'placeholder' => 'Enter Firstname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('firstname')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Lastname:*'); ?>
		<?php
			$data = array(
				'name' => 'lastname',
				'placeholder' => 'Enter Lastname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('lastname')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Email:*'); ?>
		<?php
			$data = array(
				'name' => 'email',
				'placeholder' => 'Enter Email',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('email')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Username:*'); ?>
		<?php
			$data = array(
				'name' => 'username',
				'placeholder' => 'Enter Username',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('username')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Password:*'); ?>
		<?php
			$data = array(
				'name' => 'password',
				'placeholder' => 'Enter Password',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('password')
				);
		?>
		<?php echo form_password($data); ?>
	</p>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Phone Number:*'); ?>
		<?php
			$data = array(
				'name' => 'phonenum',
				'placeholder' => 'Enter Phone Number',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('phonenum')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<p>
	<?php $data = array('value'=>'Submit',
					'name' => 'Submit',
					'class' => 'btn btn-primary');
					?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>
