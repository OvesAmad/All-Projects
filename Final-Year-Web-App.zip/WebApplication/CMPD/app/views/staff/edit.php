<?php foreach($staff_profile as $staff_profile) : ?>

	<?php $phonenum= $staff_profile->phone_number; ?>
	<?php $email=$staff_profile->email; ?>

<?php endforeach; ?>

<h1>Edit your details</h1>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class= "form-group">
	<?php $attributes = array('id' => 'staff_edit_form',
							  'class' => 'form-horizontal'); ?>
	<?php echo form_open('StaffEdit', $attributes); ?>

</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Phone Number:*'); ?>
		<?php
			$data = array(
				'name' => 'phonenum',
				'placeholder' => $phonenum,
				'style' => 'width:90%',
				'class' => 'form-control',
				'value' => set_value($phonenum)
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Email:*'); ?>
		<?php
			$data = array(
				'name' => 'email',
				'placeholder' => $email,
				'style' => 'width:90%',
				'class' => 'form-control',
				'value' => set_value($email)
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>