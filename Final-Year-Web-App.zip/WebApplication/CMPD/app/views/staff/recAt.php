<h1>Record Attendance</h1>
<table class = "table table-striped" width="50%" cellspacing="5" cellpadding="5">
	<tr>
		<th>Taster Date</th>
		<th></th>
	</tr>
	<?php if(isset($load_taster_day)) :?>
	<?php foreach($load_taster_day as $ltd) :?>
		<tr>
			<td> <?php echo $ltd->date; ?> </td>
			<td><a href="<?php echo base_url();?>studentList/load/<?php echo $ltd->taster_id;?>">Select</a></td>
		</tr>
	<?php endforeach; ?>
	<?php endif; ?>
</table>
