<?php
	if($this->session->flashdata('offered')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('offered'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('declined')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('declined'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('error')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>
<h1>Offer Place</h1>
<table class="table table-striped" width="50%" cellspacing="5" cellpadding="5">
    <tr>
    	<th>Taster ID</th>
    	<th>Applicant ID</th>
    	<th>Firstname</th>
    	<th>Lastname</th>
    	<th></th>
    	<th></th>
    </tr>
    <?php if(isset($attended_applicants)) :?>
    	<?php foreach($attended_applicants as $ap) :?>
    		<tr>
    			<td><?php echo $ap->taster_id;?></td>
    			<td><?php echo $ap->applicant_id;?></td>
    			<td><?php echo $ap->firstname;?></td>
    			<td><?php echo $ap->lastname;?></td>
    			<td><a href = "<?php echo base_url();?>/offerPlace/offer/<?php echo $ap->applicant_id;?>">Offer</a></td>
				<td><a href = "<?php echo base_url();?>/offerPlace/decline/<?php echo $ap->applicant_id;?>">Decline</a></td>
			</tr>	
    	<?php endforeach; ?>
	<?php endif; ?>
</table>