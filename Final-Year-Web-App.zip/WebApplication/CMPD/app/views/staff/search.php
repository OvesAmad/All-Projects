<h1>Search an applicant record</h1>
<h2>Enter Lastname</h2>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class = "form-group">
	<?php $attributes = array('id'=>'search_form',
								'class' => 'form-horizontal'); ?>
	<?php echo form_open('search', $attributes); ?>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Lastname:*'); ?>
		<?php
			$data = array('name'=>'lastname',
				'id'=>'lastname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Lastname/First Letter of Lastname'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<p>
	<?php $data = array('value'=>'Submit',
					'name' => 'Submit',
					'class' => 'btn btn-primary');
					?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>

<h3>Results</h3>
<table class ="table table-striped" width="50%" cellspacing="5" cellpadding="5">
	<tr>
		<th>Applicant Id</th>
		<th>First Name</th>
		<th>Last Name</th>
		<th>House Number</th>
		<th>Street Name</th>
		<th>Post Code</th>
		<th>Email</th>
		<th>Phone Number</th>
		<th>Username</th>
		<th></th>
		<th></th
	</tr>
	<?php if(isset($results)) :?>
	<?php foreach($results as $data) :?>
	<tr>
		<td> <?php echo $data->applicant_id; ?> </td>
		<td> <?php echo $data->firstname; ?> </td>
		<td> <?php echo $data->lastname; ?> </td>
		<td> <?php echo $data->housenum; ?> </td>
		<td> <?php echo $data->streetname; ?> </td>
		<td> <?php echo $data->postcode; ?> </td>
		<td> <?php echo $data->email; ?> </td>
		<td> <?php echo $data->phonenumber; ?> </td>
		<td> <?php echo $data->username; ?> </td>
		<td><a href="<?php echo base_url();?>search/edit/<?php echo $data->applicant_id;?>">Edit</a></td>
		<td><a href="<?php echo base_url();?>search/delete/<?php echo $data->applicant_id?>">Delete</a></td>
	</tr>
<?php endforeach;?>
<?php endif;?>
</table>