<?php
	if($this->session->flashdata('attended')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('attended'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('error')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>
<h1>Attendees</h1>
<table class = "table table-striped" width="50%" cellspacing="5" cellpadding="5">
	<tr>
		<th>ID</th>
		<th>Firstname</th>
		<th>Lastname</th>
		<th></th>
	</tr>
	<?php if(isset($attendees)) :?>
	<?php foreach($attendees as $attendees) :?>
		<tr>
			<td> <?php echo $attendees->applicant_id; ?> </td>
			<td> <?php echo $attendees->firstname; ?> </td>
			<td> <?php echo $attendees->lastname; ?> </td>
			<td><a href="<?php echo base_url();?>studentList/markAttended/<?php echo $attendees->applicant_id;?>/<?php echo $attendees->taster_id;?>">Mark as attended</a></td>
		</tr>
	<?php endforeach; ?>
	<?php endif; ?>
</table>