<h1>Schedule Taster Day</h1>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class="form-group">
	<?php $attributes = array('id' => 'schedule_form',
							  'class' => 'form-horizontal'); ?>
	<?php echo form_open('TDSchedule', $attributes); ?>

</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Day:*'); ?>
		<?php
			$data = array('name'=>'day',
				'id'=>'day',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'DD'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Month:*'); ?>
		<?php
			$data = array('name'=>'month',
				'id'=>'month',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'MM'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Year:*'); ?>
		<?php
			$data = array('name'=>'year',
				'id'=>'year',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'YYYY'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Time:*'); ?>
		<?php
			$data = array('name'=>'time',
				'id'=>'time',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'HH:MM'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Venue:*'); ?>
		<?php
			$data = array('name'=>'venue',
				'placeholder'=>'Enter Venue',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values'=> 'venue'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>
<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>

<h3>Scheduled Taster Days</h3>
<table class="table table-striped" width="50%" cellspacing="5" cellpadding="5">
    <tr>
    	<th>Taster ID</th>
    	<th>Taster Date</th>
    	<th>Taster Venue</th>
    	<th>Student Count</th>
    	<th></th>
    	<th></th>
    </tr>
    <?php if(isset($tasterday)) : ?>
    <?php foreach($tasterday as $day) : ?>
    	<tr>
    		<td> <?php echo $day->taster_id ?> </td>
    		<td> <?php echo $day->date ?></td>
    		<td> <?php echo $day->venue ?></td>
    		<td> <?php echo $day->student_count ?></td>
    		<td><a href="<?php echo base_url();?>TDSchedule/edit/<?php echo $day->taster_id;?>">Edit </a></td>
    		<td><a href="<?php echo base_url();?>TDSchedule/delete/<?php echo $day->taster_id;?>">Delete</a></td>
    	</tr>
    <?php endforeach; ?>
<?php endif; ?>
</table>

