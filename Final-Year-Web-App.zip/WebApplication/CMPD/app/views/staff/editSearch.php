<h1>Edit an applicant record</h1>
<h2>Complete all fields</h2>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class = "form-group">
	<?php $attributes = array('id'=>'search_form',
								'class' => 'form-horizontal'); ?>
	<?php echo form_open('search/edit/'. $this->uri->segment(3).'', $attributes); ?>
</div>
<div class = "form-group">
	<p>
		<?php echo form_label('Firstname:*'); ?>
		<?php
			$data = array('name'=>'firstname',
				'id'=>'firstname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Firstname'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Lastname:*'); ?>
		<?php
			$data = array('name'=>'lastname',
				'id'=>'lastname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Lastname'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('House Number:*'); ?>
		<?php
			$data = array('name'=>'housenum',
				'id'=>'housenum',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter House Number'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Streetname:*'); ?>
		<?php
			$data = array('name'=>'streetname',
				'id'=>'streetname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Street Name'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Postcode:*'); ?>
		<?php
			$data = array('name'=>'postcode',
				'id'=>'postcode',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Postcode'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Email:*'); ?>
		<?php
			$data = array('name'=>'email',
				'id'=>'email',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Email'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Phone number:*'); ?>
		<?php
			$data = array('name'=>'phonenumber',
				'id'=>'phonenumber',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Phone number'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<div class = "form-group">
	<p>
		<?php echo form_label('Username:*'); ?>
		<?php
			$data = array('name'=>'username',
				'id'=>'username',
				'style' => 'width:90%',
				'class' => 'form-control',
				'placeholder' => 'Enter Username'
				);
		?>
		<?php echo form_input($data);?>
	</p>
</div>

<p>
	<?php $data = array('value'=>'Submit',
					'name' => 'Submit',
					'class' => 'btn btn-primary');
					?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>