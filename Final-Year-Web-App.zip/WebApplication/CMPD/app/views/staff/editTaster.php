<h1>Edit Taster day</h1>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class= "form-group">
	<?php $attributes = array('id' => 'taster_edit_form',
							  'class' => 'form-horizontal'); ?>

	<?php echo form_open('TDSchedule/edit/'. $this->uri->segment(3).'', $attributes); ?>

</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Day:*'); ?>
		<?php
			$data = array(
				'name' => 'day',
				'placeholder' => 'Enter day',
				'style' => 'width:90%',
				'class' => 'form-control'
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Month:*'); ?>
		<?php
			$data = array(
				'name' => 'month',
				'placeholder' => 'Enter month',
				'style' => 'width:90%',
				'class' => 'form-control'
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Year:*'); ?>
		<?php
			$data = array(
				'name' => 'year',
				'placeholder' => 'Enter year',
				'style' => 'width:90%',
				'class' => 'form-control',
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Time:*'); ?>
		<?php
			$data = array(
				'name' => 'time',
				'placeholder' => 'Enter time',
				'style' => 'width:90%',
				'class' => 'form-control'
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Venue:*'); ?>
		<?php
			$data = array(
				'name' => 'venue',
				'placeholder' => 'Enter venue',
				'style' => 'width:90%',
				'class' => 'form-control'
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>