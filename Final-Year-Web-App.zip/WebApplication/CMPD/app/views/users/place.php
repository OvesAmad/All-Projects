<?php
	if($this->session->flashdata('accepted')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('accepted'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('declined')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('declined'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('error')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>

<h1>Offered Place</h2>
<table class="table table-striped" width="50%" cellspacing="5" cellpadding="5">
	<tr>
		<th>Status</th>
		<th></th>
		<th></th>
	</tr>
	<?php if(isset($offered_place)) :?>
    	<?php foreach($offered_place as $op) :?>
    		<tr>
    			<td><?php echo $op->place_offered;?></td>
    			<?php 
    				$offer =$op->place_offered;    			
    				if($offer == 'na' || $offer == 'N'):
				?>
					<td></td>
					<td></td>
				<?php else: ?>
    				<td><a href = "<?php echo base_url();?>/studentPlace/accept/<?php echo $this->session->userdata('user_id');?>">Accept</a></td>
					<td><a href = "<?php echo base_url();?>/studentPlace/decline/<?php echo $this->session->userdata('user_id');?>">Decline</a></td>
				<?php endif;?>
			</tr>	
    	<?php endforeach; ?>
	<?php endif; ?>
</table>