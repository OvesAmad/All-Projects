<h1>Register Now</h1>
<h2>Please fill out all information.</h2>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class= "form-group">
	<?php $attributes = array('id' => 'register_form',
							  'class' => 'form-horizontal'); ?>
	<?php echo form_open('users/register', $attributes); ?>

</div>
<h3>Personal Details</h3>
<div class= "form-group">
	<p>
		<?php echo form_label('Firstname:*'); ?>
		<?php
			$data = array(
				'name' => 'firstname',
				'placeholder' => 'Enter firstname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('firstname')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<div class= "form-group">
	<p>
		<?php echo form_label('Lastname:*'); ?>
		<?php
			$data = array(
				'name' => 'lastname',
				'placeholder' => 'Enter lastname',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('lastname')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<div class= "form-group">
	<p>
		<?php echo form_label('House/Flat Number:*'); ?>
		<?php
			$data = array(
				'name' => 'housenum',
				'placeholder' => 'Enter House/Flat Number',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('housenum')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Street Name:*'); ?>
		<?php
			$data = array(
				'name' => 'streetname',
				'placeholder' => 'Enter Street Name',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('streetname')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Post Code:*'); ?>
		<?php
			$data = array(
				'name' => 'postcode',
				'placeholder' => 'Enter Post Code',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('postcode')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Email:*'); ?>
		<?php
			$data = array(
				'name' => 'email',
				'placeholder' => 'Enter Email Address',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('email')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Telephone Number:*'); ?>
		<?php
			$data = array(
				'name' => 'telephone',
				'placeholder' => 'Enter Telephone Number',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('telephone')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>IF NO DISABILITIES PLEASE TYPE 'NONE'</p>
	<p> 
		<?php echo form_label('Any Disabilities?'); ?>
		<?php
			$data = array(
				'name' => 'disabilities',
				'placeholder' => 'Enter any disabilities you may have',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('disabilities')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>IF NO ADDITIONAL INFO PLEASE TYPE 'NONE'</p>
	<p>
		<?php echo form_label('Anything we should know about?'); ?>
		<?php
			$data = array(
				'name' => 'addinfo',
				'placeholder' => 'Enter any additional information',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('addinfo')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>

<h3>Login Details.</h3>
<div class= "form-group">
	<p>
		<?php echo form_label('Username:*'); ?>
		<?php
			$data = array(
				'name' => 'username',
				'placeholder' => 'Enter username',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('username')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Password:*'); ?>
		<?php
			$data = array(
				'name' => 'password',
				'placeholder' => 'Enter password',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('password')
				);
		?>
		<?php echo form_password($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Confirm Password:*'); ?>
		<?php
			$data = array(
				'name' => 'password2',
				'placeholder' => 'Enter password again',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('password2')
				);
		?>
		<?php echo form_password($data); ?>
	</p>
</div>

<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>


