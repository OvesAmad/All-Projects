<h1>Login Now</h1>
<?php echo validation_errors('<p class="alert alert-danger">'); ?>
<div class= "form-group">
	<?php $attributes = array('id' => 'login_form',
							  'class' => 'form-horizontal'); ?>
	<?php echo form_open('users/login', $attributes); ?>

</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Username:*'); ?>
		<?php
			$data = array(
				'name' => 'username',
				'placeholder' => 'Enter username',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('username')
				);
		?>
		<?php echo form_input($data); ?>
	</p>
</div>
<div class= "form-group">
	<p>
		<?php echo form_label('Password:*'); ?>
		<?php
			$data = array(
				'name' => 'password',
				'placeholder' => 'Enter password',
				'style' => 'width:90%',
				'class' => 'form-control',
				'values' => set_value('password')
				);
		?>
		<?php echo form_password($data); ?>
	</p>
</div>

<p>
	<?php $data = array('value' => 'Submit',
		 	  'name' => 'Submit',
		 	  'class' => 'btn btn-primary');
		 	  ?>
	<?php echo form_submit($data); ?>
</p>
<?php echo form_close(); ?>


