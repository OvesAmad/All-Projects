<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FYC</title>
 
    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet">
 
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class = "container">
      <div class = "row">
        <div class= "col-md-12">
          <img src="<?php echo base_url(); ?>assets/img/banner2.jpg" alt="Banner2" class="img-responsive"/>
        </div>
      </div>
    </div>
    <div class = "container">
      <div class = "row">
        <div class = "col-md-12">
          <ul>
            <?php if($this->session->userdata('logged_in') && $this->session->userdata('is_user')):?>
              <li><a href="<?php echo base_url(); ?>profile" style= "text-decoration:none">My Profile</a></li>
              <li><a href="<?php echo base_url(); ?>taster" style= "text-decoration:none">Attend Taster Day</a></li>
              <li><a href="<?php echo base_url(); ?>studentPlace" style= "text-decoration:none">Offers</a></li>
              <li><a href="<?php echo base_url(); ?>edit" style= "text-decoration:none">Edit Profile</a></li>
            <?php elseif($this->session->userdata('logged_in') && $this->session->userdata('is_staff')) :?>
              <li><a href="<?php echo base_url(); ?>Staffprofile" style= "text-decoration:none">My Profile</a></li>
              <li><a href="<?php echo base_url(); ?>search" style= "text-decoration:none">Search Applicant</a></li>
              <li><a href="<?php echo base_url(); ?>StaffEdit" style= "text-decoration:none">Edit profile</a></li>
            <?php elseif($this->session->userdata('logged_in') && $this->session->userdata('is_admin')) :?>
              <li><a href="<?php echo base_url(); ?>Staffprofile" style= "text-decoration:none">My Profile</a></li>
              <li><a href="<?php echo base_url(); ?>search" style= "text-decoration:none">Search Applicant</a></li>
              <li><a href="<?php echo base_url(); ?>TDschedule" style= "text-decoration:none">Schedule TD</a></li>
              <li><a href="<?php echo base_url(); ?>recAttendance" style= "text-decoration:none">Record Attendance</a></li>
              <li><a href="<?php echo base_url(); ?>offerPlace" style= "text-decoration:none">Offer Place</a></li>
              <li><a href="<?php echo base_url(); ?>StaffCreate" style= "text-decoration:none">Create Account</a></li>
              <li><a href="<?php echo base_url(); ?>StaffEdit" style= "text-decoration:none">Edit profile</a></li>
            <?php elseif($this->session->userdata('logged_in') && $this->session->userdata('is_co')) :?>
              <li><a href="<?php echo base_url(); ?>Staffprofile" style= "text-decoration:none">My Profile</a></li>
              <li><a href="<?php echo base_url(); ?>search" style= "text-decoration:none">Search Applicant</a></li>
              <li><a href="<?php echo base_url(); ?>TDschedule" style= "text-decoration:none">Schedule TD</a></li>
              <li><a href="<?php echo base_url(); ?>recAttendance" style= "text-decoration:none">Record Attendance</a></li>
              <li><a href="<?php echo base_url(); ?>StaffEdit" style= "text-decoration:none">Edit profile</a></li>
            <?php else : ?>
              <li><a href="<?php echo base_url(); ?>" style= "text-decoration:none">Home</a></li>
              <li><a href="<?php echo base_url(); ?>information" style= "text-decoration:none">Information</a></li>
              <li><a href="<?php echo base_url(); ?>FAQ" style= "text-decoration:none">FAQ</a></li>
            <?php endif ;?>
              <ul style="float:right;list-style-type:none;">
            <?php if($this->session->userdata('logged_in')) : ?>
                <li><a href="<?php echo base_url(); ?>users/logout" style= "text-decoration:none">Logout</a></li>
            <?php else :?>
                <li><a href="<?php echo base_url(); ?>users/login" style= "text-decoration:none">Login</a></li>
                <li><a href="<?php echo base_url(); ?>users/register" style= "text-decoration:none">Register</a></li>
            <?php endif ;?>
              </ul>
            

            </ul>
          </ul>
        </div>
      </div>
    </div>
    <!--Main content goes here-->
    <div class = "container">
      <div class = "row">
        <div class = "col-md-12">
           
          <!--Main content is here -->
            <?php $this->load->view($main_content); ?>

        </div>
      </div>
    </div>


  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="//cdn.jsdelivr.net/webshim/1.14.5/polyfiller.js"></script>
  <script>
    webshims.setOptions('forms-ext', {types: 'date'});
    webshims.polyfill('forms forms-ext');
  </script>
  </body>
    
</html>