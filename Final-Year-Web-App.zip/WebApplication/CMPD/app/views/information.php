<h1>Additional information for the course</h1>
<h4><b>Reasons to study a Foundation Year in Computing at De Montfort University:</b></h4>
<p><b>YOU ARE ONLY ALLOWED TO SUBMIT THE TASTER FORM 4 TIMES</b></p>
<ol>
    <li>If you missed the chance to go to university after school, if you’re looking for a change of career, or if you’re a parent planning to return to employment, our foundation in Computing is the ideal course</li>
    <li>This course can be a stepping stone to one of our undergraduate degrees and is a good place to start if you’re considering returning to study</li>
    <li>Our software is often accessible via remote access, enabling you to work from home when there are no staff classes</li>
    <li>As a student at DMU, you will have the opportunity to take part in a meaningful international experience with #DMUglobal</li>
	<br><br>
</ol>
<p>The course covers the basics of cutting-edge IT topics, such as computer animation, as well as more familiar office applications, such as spreadsheets and databases. Staff and students work together in a friendly and supportive workshop environment.</p>
<br>
<h4><b>Requirements</b></h4>

<p><b>3 GCSE's at grade A-C:</b><br></p>
<ol>
	<li>English</li><br>
	<li>Maths</li><br>
	<li>Science</li>
</ol>
<br>
<p><b>1 A level (Distinction - Pass):</b><br></p>
<ol>
	<li>ICT</li>
</ol>
