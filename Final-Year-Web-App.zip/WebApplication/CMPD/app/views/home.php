<!--<img class="img-responsive" src="http://placehold.it/2000x1333" alt="Campus Center">-->
<?php
	if($this->session->flashdata('registered')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('registered'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('regfail')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('regfail'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('login_success')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('login_success'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('login_failed')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('login_failed'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('logged_out')):
?>
	<p class="alert alert-success"><?php echo $this->session->flashdata('logged_out'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('noaccess')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('noaccess'); ?></p>
<?php endif; ?>
<?php
	if($this->session->flashdata('alreadyScheduled')):
?>
	<p class="alert alert-danger"><?php echo $this->session->flashdata('alreadyScheduled'); ?></p>
<?php endif; ?>
<h1> Welcome to Foundation Year in Computing!</h1>
<p>This full-time, one-year foundation course provides an introduction to computing and information technology and gives students without the necessary qualifications the skills required to study an undergraduate computing course at the most improved university in Britain.</p>
<p>The course covers the basics of cutting-edge IT topics, such as computer animation, as well as more familiar office applications, such as spreadsheets and databases. Staff and students work together in a friendly and supportive workshop environment. - To See more: <a href="http://www.dmu.ac.uk/study/courses/undergraduate-courses/foundation-year-in-computing.aspx#sthash.6JASq1tr.dpuf">Click Here</a></p>