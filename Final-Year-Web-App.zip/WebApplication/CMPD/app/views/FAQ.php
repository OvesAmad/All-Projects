<h1>FAQ</h1>
<h3>After I register, how long will take for my user area to be created?</h3>
<p><b>The user area is created staright away and you can log on as soon as you register</b></p>
<br>
<h3>How do I get an invite?</h3>
<p><b>In order to get an invite you will be need to meet the requirements on the information page and apply by registering on the website.</b></p>
<br>
<h3>How long does the taster day last</h3>
<p><b>The taster day can last upto 3hrs<b></p>
<br>
<h3>Do I have to attend a taster day in order to get on the course</h3>
<p><b>Yes this is a mandatory requirement</b></p>