<?php
class FAQ extends CI_Controller{
	public function index(){
		$data['main_content'] = 'FAQ';
		$this->load->view('layouts/main', $data);
	}
}