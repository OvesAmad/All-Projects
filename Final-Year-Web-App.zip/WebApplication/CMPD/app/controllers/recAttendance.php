<?php
class RecAttendance extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in') && (!$this->session->userdata('is_co') || !$this->session->userdata('is_admin'))){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$data['main_content'] = 'staff/recAt';
		$data['load_taster_day'] = $this->User_model->getTasterDay();
		$this->load->view('layouts/main', $data);
	}



}