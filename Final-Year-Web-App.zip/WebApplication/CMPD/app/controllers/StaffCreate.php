<?php
class StaffCreate extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if(!$this->session->userdata('logged_in') && !$this->session->$userdata('is_admin')){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$this->form_validation->set_rules('firstname', 'Firstname','trim|required|max_length[255]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('lastname', 'Lastname','trim|required|max_length[255]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('email','Email','trim|required|max_length[255]|min_length[10]|xss_clean');
		$this->form_validation->set_rules('username', 'Username','trim|required|max_length[255]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('password', 'Password','trim|required|max_length[255]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('phonenum','Phone Number','trim|required|max_length[20]|min_length[7]|xss_clean');
		
		if($this->form_validation->run() == FALSE){
			$data['main_content'] = 'staff/register';
			$this->load->view('layouts/main',$data);
		}else{
			if($this->Staff_model->create_staff()){
				$this->session->set_flashdata('registered', 'Staff member is now registered and can now log in');
				redirect('StaffCreate/index');
			}else{
				$this->session->set_flashdata('error', 'Oops, Something went wrong please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
				redirect('StaffCreate/index');
			}
		}
	}
}
