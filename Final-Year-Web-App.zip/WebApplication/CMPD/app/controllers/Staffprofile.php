<?php
class Staffprofile extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if(!$this->session->userdata('logged_in') && (!$this->session->$userdata('is_staff') || !$this->session->$userdata('is_admin') || !$this->session->$userdata('is_co'))){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$staff_id = $this->session->userdata('user_id');
		$data['profile'] = $this->Profile_model->get_staff_profile($staff_id);

		$data['main_content'] = "staff/index";
		$this->load->view('layouts/main', $data);


	}
}