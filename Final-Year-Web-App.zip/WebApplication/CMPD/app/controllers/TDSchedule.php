<?php
class TDSchedule extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in') && (!$this->session->userdata('is_admin') || !$this->session->userdata('is_co'))){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
}

	public function index(){
		$this->form_validation->set_rules('day', 'Day', 'trim|required|max_length[2]|min_length[1]|less_than[32]|greater_than[0]|xss_clean');
		$this->form_validation->set_rules('month', 'Month', 'trim|required|max_length[2]|min_length[1]|less_than[13]|greater_than[0]|xss_clean');
		$this->form_validation->set_rules('year', 'Year', 'trim|required|max_length[4]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('venue', 'Venue', 'trim|required|max_length[255]|min_length[3]|xss_clean');


		if($this->form_validation->run() == FALSE){
			$data['tasterday'] = $this->Staff_model->get_all_tasterdays();
			$data['main_content'] = 'staff/schedule';
			$this->load->view('layouts/main', $data);
		}else{
			$date = "";
			$day = $this->input->post('day');
			$month = $this->input->post('month');
			$year = $this->input->post('year');
			$time = $this->input->post('time');
			
			if($year < date('Y')){
				$this->session->set_flashdata('not_scheduled', 'Taster day NOT scheduled! Invalid data');
				redirect('Staffprofile/index');
			}else {
				$date = $day . "-" . $month . "-" . $year . " -" . $time;
			}
		if($this->Staff_model->scheduleTD($date)){
			$this->session->set_flashdata('scheduled', 'Taster day successfully scheduled.');
			redirect('Staffprofile/index');
		}else{
;			$this->session->set_flashdata('not_scheduled', 'Taster day NOT scheduled! Invalid data');
			redirect('Staffprofile/index');
		}
		}
	}

	public function edit($id){
		$getId = $id;
		
		// USED FOR DEBUGGING PURPOSES var_dump($getId);
		$this->form_validation->set_rules('day', 'Day', 'trim|required|max_length[2]|min_length[1]|xss_clean');
		$this->form_validation->set_rules('month', 'Month', 'trim|required|max_length[2]|min_length[1]|xss_clean');
		$this->form_validation->set_rules('year', 'Year', 'trim|required|max_length[4]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('time', 'Time', 'trim|required|max_length[7]|min_length[2]|xss_clean');
		$this->form_validation->set_rules('venue', 'Venue', 'trim|required|max_length[255]|min_length[3]|xss_clean');

		if($this->form_validation->run() == FALSE){
			$data['main_content'] = 'staff/editTaster';
			$this->load->view('layouts/main', $data);
			// USED FOR DEBUGGING PURPOSES 	var_dump($getId);
		}else{
			
			// USED FOR DEBUGGING PURPOSES $afterId = $this->Staff_model->editTD($getId);
			// USED FOR DEBUGGING PURPOSES var_dump($getId);	
			if($this->Staff_model->editTD($getId)){
				//Create Flash data
				$this->session->set_flashdata('editSuccess', 'Taster day successfully edited.');
				redirect('Staffprofile/index');
			}else{
				$this->session->set_flashdata('editFailed', 'Taster day FAILED to edit.');
				redirect('Staffprofile/index');
			}
		}
		
		
	}

	public function delete($id){
		if($this->Staff_model->deleteTD($id)){
			//Create Flash data
			$this->session->set_flashdata('deleteSuccess', 'Taster day successfully deleted.' . $id);
			redirect('Staffprofile/index');
		}else{
			$this->session->set_flashdata('deleteFailed', 'Error: Taster day could NOT be deleted.');
			redirect('Staffprofile/index');
		}
	}
}