<?php
class Users extends CI_Controller{
	public function register(){
		$this->form_validation->set_rules('firstname','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('lastname','Last Name','trim|required|max_length[50]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('housenum','House Number','trim|required|max_length[5]|min_length[1]|xss_clean');

		$this->form_validation->set_rules('streetname','Street Name','trim|required|max_length[100]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('postcode','Post Code','trim|required|max_length[50]|min_length[6]|xss_clean');

		$this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|valid_email|xss_clean');

		$this->form_validation->set_rules('telephone','Telephone Number','trim|required|max_length[50]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('disabilities','Disabilities','trim|max_length[500]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('addinfo','Additional Information','trim|max_length[500]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('username','Username','trim|required|max_length[20]|min_length[6]|xss_clean');

		$this->form_validation->set_rules('password','Password','trim|required|max_length[50]|min_length[6]|xss_clean');

		$this->form_validation->set_rules('password2','Confirm Password','trim|required|max_length[50]|min_length[6]|matches[password]|xss_clean');

		if($this->form_validation->run() == FALSE){
			$data['main_content'] = 'users/register';
			$this->load->view('layouts/main', $data);
		}else{
			if($this->User_model->create_user()){
				$this->session->set_flashdata('registered', 'You are now registered and can now log in');
				redirect('home/index');
			}
		}
	}

	public function login(){
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[2]|max_length[50]|xss_clean');
	
		if($this->form_validation->run() == FALSE){
			$data['main_content'] = 'users/login';
			$this->load->view('layouts/main', $data);
		}else{
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			
			$user_id_applicant = $this->User_model->login_user($username, $password);

			$user_id_staff = $this->User_model->login_staff($username, $password);

			$user_type_staff = $this->User_model->get_staff_type($username, $password);
			
			if($user_id_applicant){
				$user_data = array(
							'user_id'   => $user_id_applicant,
							'username'  => $username,
							'logged_in' => true,
							'is_user'   => true
							);
				$this->session->set_userdata($user_data);
				$this->session->set_flashdata('login_success', 'You have logged in successfully.');
				redirect('profile/index');}
			if($user_type_staff == '2'){
				$staff_data = array('user_id' => $user_id_staff,
									'username' => $username,
									'logged_in' => true,
									'is_staff' => true
									);
				$this->session->set_userdata($staff_data);
				$this->session->set_flashdata('login_success', 'You have logged in successfully.(Staff)');
				redirect('Staffprofile/index');
			}else if($user_type_staff == '1'){
				$admin_data = array('user_id' => $user_id_staff,
									'username' => $username,
									'logged_in' => true,
									'is_admin' => true
									);
				$this->session->set_userdata($admin_data);
				$this->session->set_flashdata('login_success', 'You have logged in successfully.(Admin)');
				redirect('Staffprofile/index');
			}else if($user_type_staff == '3'){
				$co_data = array('user_id' => $user_id_staff,
									'username' => $username,
									'logged_in' => true,
									'is_co' => true
									);
				$this->session->set_userdata($co_data);
				$this->session->set_flashdata('login_success', 'You have logged in successfully.(Coordinator)');
				redirect('Staffprofile/index');}
				else{
				$this->session->set_flashdata('login_failed', 'Sorry, the login information you provided is invalid.');
				redirect('home/index');
			}
			
				
		}

	}

	public function logout(){
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('logged_in');
		$this->session->unset_userdata('is_user');
		$this->session->unset_userdata('is_staff');
		$this->session->unset_userdata('is_co');
		$this->session->unset_userdata('is_admin');
		$this->session->sess_destroy();
		$this->session->set_flashdata('logged_out', 'You have successfully looged out');
		redirect('home/index');
	}

}