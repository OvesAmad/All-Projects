<?php
class StudentPlace extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in') && !$this->session->userdata('is_admin')){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$data['main_content'] = 'users/place';
		$data['offered_place'] = $this->User_model->check_if_offered($this->session->userdata('user_id'));
		$this->load->view('layouts/main', $data);
	}

	public function accept($id){
		if($this->User_model->acceptPos($id)){
			$this->session->set_flashdata('accepted', 'You have accepted this offer.');
			redirect('studentPlace/index');

		}else{
			$this->session->set_flashdata('error', 'Oops, Something went wrong please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
			redirect('profile/index');
		}
	}

	public function decline($id){
		if($this->User_model->declinePos($id)){
			$this->session->set_flashdata('declined', 'You have declined this offer.');
			redirect('studentPlace/index');
		}else{
			$this->session->set_flashdata('error', 'Oops, Something went wrong please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
			redirect('profile/index');

		}
	}
}