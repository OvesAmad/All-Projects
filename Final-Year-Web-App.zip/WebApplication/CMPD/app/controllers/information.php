<?php
class Information extends CI_Controller{
	public function index(){
		$data['main_content'] = 'information';
		$this->load->view('layouts/main', $data);
	}
}