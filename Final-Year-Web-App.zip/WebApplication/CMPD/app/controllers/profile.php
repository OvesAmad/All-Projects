<?php
class Profile extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if(!$this->session->userdata('logged_in') && !$this->session->userdata('is_user')){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){

		$user_id = $this->session->userdata('user_id');
		$data['profile'] = $this->Profile_model->get_profile($user_id);
		
		

		$data['main_content'] = 'profile/index';
		$this->load->view('layouts/main', $data);
	}

	
}