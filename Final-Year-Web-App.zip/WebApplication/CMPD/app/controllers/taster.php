<?php
class Taster extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if(!$this->session->userdata('logged_in') && !$this->session->userdata('is_user')){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}
	public function index(){
		$this->form_validation->set_rules('english','English','trim|required|max_length[2]|min_length[1]|xss_clean');
		$this->form_validation->set_rules('maths','Maths','trim|required|max_length[2]|min_length[1]|xss_clean');
		$this->form_validation->set_rules('science','Science','trim|required|max_length[2]|min_length[1]|xss_clean');

		if($this->form_validation->run()==FALSE){
			$data['main_content'] = 'profile/taster';
			$this->load->view('layouts/main', $data);
		}else{
			$english = $this->input->post('english');
			$maths = $this->input->post('maths');
			$science = $this->input->post('science');
			$ict = $this->input->post('ict');

			$RegEng = preg_match('/A|B|C/', $english); //Use of regular expressions to determine the grade
			$RegMaths = preg_match('/A|B|C/', $maths);
			$RegScience = preg_match('/A|B|C/', $science);
			$RegICT = preg_match('/A|B|C/', $ict);
			if($RegEng && $RegMaths && $RegScience && $RegICT){
				$this->User_model->addEnglish($english);
				$this->User_model->addScience($science);
				$this->User_model->addMaths($maths);
				$this->User_model->addICT($ict);
				if($this->User_model->createApplication()){
					$load = $this->User_model->loadTasterDays();
					if($load != false){
						$data['taster_days'] = $load;
						$data['main_content'] = 'profile/taster';
						$this->load->view('layouts/main', $data);
					}else{
						$this->session->set_flashdata('error', 'Oops, No upcoming taster days/no space available/You have applied more than three times please try again later or contact the site admin at: p1318595x@mydmu.ac.uk');
						redirect('taster/index');
					}

				}else{
					$this->session->set_flashdata('error', 'Oops, Something went wrong/You have applied more than three times please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
					redirect('taster/index');
				}
			}else{
				$this->User_model->addEnglish($english);
				$this->User_model->addScience($science);
				$this->User_model->addMaths($maths);
				$this->User_model->addICT($ict);
				$this->User_model->createApplication();
				$this->session->set_flashdata('error', 'Oops, You do not meet the requirements please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
				redirect('profile/index');
			}
		}
	}

	public function select($id){
		
		if($this->User_model->addApplicantToTasterDay($id ,$this->session->userdata('user_id'))){
			$this->session->set_flashdata('selected','You have been added to this scheduled taster day.');
			
			redirect('taster/index');
		}else{
			$this->session->set_flashdata('error', 'You have already been invited to a taster day, please contact the site admin at: p1318595x@mydmu.ac.uk');
			redirect('taster/index');
		}
	}
}