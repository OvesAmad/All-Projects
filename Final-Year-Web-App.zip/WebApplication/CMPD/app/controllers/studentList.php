<?php
class StudentList extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in') && (!$this->session->userdata('is_admin') || !$this->session->userdata('is_co'))){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function load($id){
		$data['main_content'] = 'staff/studentList';
		$data['attendees'] = $this->User_model->loadAttendees($id);
		$this->load->view('layouts/main', $data);
	}

	public function markAttended($id,$tid){
		if($this->User_model->recordAsAttended($id)){
			$this->session->set_flashdata('attended', 'Applicant has been marked as attended successfully');
			redirect('StudentList/load/'.$tid.'');
		}else{
			$this->session->set_flashdata('error', 'Oops, Something went wrong please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
			redirect('Staffprofile/index');
		}
	}

}