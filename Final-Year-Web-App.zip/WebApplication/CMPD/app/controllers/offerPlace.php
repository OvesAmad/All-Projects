<?php
class OfferPlace extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in') && !$this->session->userdata('is_admin')){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$data['main_content'] = 'staff/offer';
		$data['attended_applicants'] = $this->User_model->attended_applicants();
		$this->load->view('layouts/main', $data);
	}

	public function offer($id){
		if($this->User_model->offerPlaceAccept($id)){
			$this->session->set_flashdata('offered', 'You have successfully offered a place to the selected student.');
			redirect('offerPlace/index');
		}else{
			$this->session->set_flashdata('error', 'Oops, Something went wrong please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
			redirect('offerPlace/index');
		}
	}

	public function decline($id){
		if($this->User_model->offerPlaceDecline($id)){
			$this->session->set_flashdata('declined', 'You have successfully declined a place to the selected student.');
			redirect('offerPlace/index');
		}else{
			$this->session->set_flashdata('error', 'Oops, Something went wrong please try again or contact the site admin at: p1318595x@mydmu.ac.uk');
			redirect('offerPlace/index');
		}
	}


}