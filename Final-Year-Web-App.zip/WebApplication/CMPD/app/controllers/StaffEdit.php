<?php
class StaffEdit extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if(!$this->session->userdata('logged_in') && (!$this->session->$userdata('is_staff') || !$this->session->$userdata('is_admin') || !$this->session->$userdata('is_co'))){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

		public function index(){
		$this->form_validation->set_rules('phonenum','Phone Number','trim|required|max_length[20]|min_length[7]|xss_clean');

		$this->form_validation->set_rules('email','Email','trim|required|max_length[255]|min_length[20]|xss_clean');


		if($this->form_validation->run() == FALSE){
			$user_id = $this->session->userdata('user_id');
			
			$data['staff_profile'] = $this->Staff_model->get_staff_data($user_id);

			$data['main_content'] = 'staff/edit';
			$this->load->view('layouts/main', $data);
		}else{
			$data = array(
					'phone_number' => $this->input->post('phonenum'),
					'email' => $this->input->post('email')
					);
			if($this->Staff_model->edit_profile($this->session->userdata('user_id'), $data)){
				$this->session->set_flashdata('profile_updated', 'Your Profile has been updated.');
				redirect('Staffprofile/index');
			}else{
				$this->session->set_flashdata('profile_failed', 'Your Profile has NOT been updated.');
				redirect('Staffprofile/index');
			}
		}

	}
}