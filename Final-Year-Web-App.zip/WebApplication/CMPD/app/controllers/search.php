<?php
class Search extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in') && (!$this->session->$userdata('is_staff') || !$this->session->$userdata('is_admin') || !$this->session->$userdata('is_co'))){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$this->form_validation->set_rules('lastname', 'Lastname', 'trim|required|max_length[255]|min_length[1]|xss_clean');
		if($this->form_validation->run() == FALSE){
			$data['main_content'] = 'staff/search';
			$this->load->view('layouts/main', $data);
		}
		else{
			$search = $this->input->post('lastname');
			$data['results'] = $this->Staff_model->search($search);
			$data['main_content'] = 'staff/search';
			$this->load->view('layouts/main', $data);
		}
		
	}

	public function edit($id){
		$this->form_validation->set_rules('firstname','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('lastname','Last Name','trim|required|max_length[50]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('housenum','House Number','trim|required|max_length[5]|min_length[1]|xss_clean');

		$this->form_validation->set_rules('streetname','Street Name','trim|required|max_length[100]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('postcode','Post Code','trim|required|max_length[50]|min_length[6]|xss_clean');

		$this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|valid_email|xss_clean');

		$this->form_validation->set_rules('phonenumber','Phone Number','trim|required|max_length[50]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('username','Username','trim|required|max_length[20]|min_length[6]|xss_clean');

		if($this->form_validation->run() == FALSE){
			$data['main_content'] = 'staff/editSearch';
			$this->load->view('layouts/main', $data);
		}else{
			if($this->Staff_model->editAP($id)){
				$this->session->set_flashdata('editSuccess', 'Applicant successfully edited.');
				redirect('StaffProfile/index');
			}else{
				$this->session->set_flashdata('editFailed', 'Applicant FAILED to edit.');
				redirect('StaffProfile/index');
			}
			
		}
	}

	public function delete($id){
		if($this->Staff_model->deleteAP($id)){
			$this->session->set_flashdata('deleteSuccess', 'Applicant successfully deleted.');
			redirect('StaffProfile/index');
		}else{
			$this->session->set_flashdata('deleteFailed', 'Error: Applicant could NOT be deleted.');
			redirect('StaffProfile/index');
		}
	}
}