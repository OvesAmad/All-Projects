<?php
class Edit extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if(!$this->session->userdata('logged_in') && !$this->session->userdata('is_user')){
			$this->session->set_flashdata('noaccess', 'Access Denied: You are NOT logged in!');
			redirect('home/index');
		}
	}

	public function index(){
		$this->form_validation->set_rules('housenum','House Number','trim|required|max_length[5]|min_length[1]|xss_clean');

		$this->form_validation->set_rules('streetname','Street Name','trim|required|max_length[100]|min_length[2]|xss_clean');

		$this->form_validation->set_rules('postcode','Post Code','trim|required|max_length[50]|min_length[6]|xss_clean');

		$this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|valid_email|xss_clean');

		$this->form_validation->set_rules('telephone','Telephone Number','trim|required|max_length[50]|min_length[2]|xss_clean');

		if($this->form_validation->run() == FALSE){
			$user_id = $this->session->userdata('user_id');
			$data['user_profile'] = $this->Profile_model->get_user_data($user_id);

			$data['main_content'] = 'profile/edit';
			$this->load->view('layouts/main', $data);
		}else{
			$data = array(
					'housenum' => $this->input->post('housenum'),
					'streetname' => $this->input->post('streetname'),
					'postcode' => $this->input->post('postcode'),
					'email'	=> $this->input->post('email'),
					'phonenumber'=> $this->input->post('telephone')
					);
			if($this->Profile_model->edit_profile($this->session->userdata('user_id'), $data)){
				$this->session->set_flashdata('profile_updated', 'Your Profile has been updated.');
				redirect('profile/index');
			}else{
				$this->session->set_flashdata('profile_failed', 'Your Profile has NOT been updated.');
				redirect('profile/index');
			}
		}

	}
}