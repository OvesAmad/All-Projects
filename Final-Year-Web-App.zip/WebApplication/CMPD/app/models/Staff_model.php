<?php
class Staff_model extends CI_Model{
	public function get_staff_data($staff_id){
		$this->db->where('staff_id', $staff_id);
		$query = $this->db->get('staff');
		if($query->num_rows() == 1){
			return $query->result();
		}
	}

		public function edit_profile($user_id, $data){
		$this->db->where('staff_id', $user_id);
		$this->db->update('staff',$data);
		return TRUE;
	}

	public function create_staff(){
		$enc_password = sha1($this->input->post('password'));

		$username = $this->input->post('username');

		$this->db->where('username', $username);
		$result = $this->db->get('applicant');
		$row    = $result->num_rows();

		if($row == 0){
			$data = array(
				'staff_type_id' => $this->input->post('class'),
				'firstname' => $this->input->post('firstname'),
				'lastname'	=> $this->input->post('lastname'),
				'email'		=> $this->input->post('email'),
				'username' 	=> $username,
				'password'  => $enc_password,
				'phone_number'  => $this->input->post('phonenum')
				);
			$insert = $this->db->insert('staff', $data);
			return $insert;
		}else{
			$this->session->set_flashdata('regfail', 'Registeration failed, username exists, please use a different username!');
			redirect('home/index');
		}
	}

	public function scheduleTD($date){

		$this->db->where('date', $date);
		$result = $this->db->get('taster_day');
		$row = $result->num_rows();
		
		if($row == 0){
		$data = array(
				'staff_id' => $this->session->userdata('user_id'),
				'date'=> $date, //Pass in concatenated string
				'venue'=> $this->input->post('venue'),
				'student_count' => 0
			);
		$insert = $this->db->insert('taster_day', $data);
		return $insert;
		}else{
			$this->session->set_flashdata('alreadyScheduled', 'Taster day already exists!');
			redirect('home/index');
		}
	}

	public function get_all_tasterdays(){
		$result = $this->db->get('taster_day');
		return $result->result();
	}

	public function editTD($id){
			$date = "";
			$day = $this->input->post('day');
			$month = $this->input->post('month');
			$year = $this->input->post('year');
			$time = $this->input->post('time');
			if(($day <= 00 || $day > 31) && ($month <= 00 || $month > 12) && ($year < date("Y"))){
				$this->session->set_flashdata('not_scheduled', 'Taster day NOT scheduled! Invalid data');
			}else {
				$date = $day . "-" . $month . "-" . $year . " -" . $time;
			}
			$data = array(
				'staff_id' => $this->session->userdata('user_id'),
				'date' => $date,
				'venue' => $this->input->post('venue'),
				'student_count' => 0
				);


		$this->db->where('taster_id', $id);
		$result = $this->db->get('taster_day');
		$row= $result->num_rows();
		if($row==1){
			$this->db->where('taster_id', $id);
			$this->db->update('taster_day', $data);
			return TRUE;
		}else{
			return FALSE;
		}

		
	}

	public function getStudentCount($id){

	}

	public function deleteTD($id){
		$this->db->where('taster_id', $id);
		$this->db->delete('taster_day');
		return TRUE;
	}

	public function search($letter){
		$this->db->like('lastname',$letter,'after');
		$result = $this->db->get('applicant');
		return $result->result();
	}

	public function deleteAP($id){
		$this->db->where('applicant_id', $id);
		$this->db->delete('applicant');
		return TRUE;
	}

	public function editAP($id){
		$firstname = $this->input->post('firstname');
		$lastname = $this->input->post('lastname');
		$housenum = $this->input->post('housenum');
		$streetname = $this->input->post('streetname');
		$postcode = $this->input->post('postcode');
		$email = $this->input->post('email');
		$phonenumber = $this->input->post('phonenumber');
		$username = $this->input->post('username');

		$data = array(
			'firstname' => $firstname,
			'lastname' => $lastname,
			'housenum' => $housenum,
			'streetname' => $streetname,
			'postcode' => $postcode,
			'email' => $email,
			'phonenumber' => $phonenumber,
			'username' => $username);
		$this->db->where('applicant_id', $id);
		$result = $this->db->get('applicant');
		$row = $result->num_rows();
		if($row == 1){
			$this->db->where('applicant_id', $id);
			$this->db->update('applicant', $data);
			return TRUE;
		}else{
			return FALSE;
		}
			
	}
}