<?php
class Profile_model extends CI_model{
	public function get_profile($id){
		
		$this->db->where('applicant_id', $id);
		$query = $this->db->get('applicant');

		if($query->num_rows()==1){
			return $query->result();
		}
	}

	public function edit_profile($user_id, $data){
		$this->db->where('applicant_id', $user_id);
		$this->db->update('applicant',$data);
		return TRUE;
	}

	public function get_user_data($user_id){
		$this->db->where('applicant_id', $user_id);
		$query = $this->db->get('applicant');
		if($query->num_rows()==1){
			return $query->result();
		}
	}

	public function get_staff_profile($id){
		$this->db->where('staff_id', $id);
		$query = $this->db->get('staff');

		if($query->num_rows() == 1){
			return $query->result();
		}
	}


}