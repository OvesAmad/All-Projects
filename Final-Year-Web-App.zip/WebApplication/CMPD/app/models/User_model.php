 <?php
class User_model extends CI_Model{
	public function create_user(){
		$enc_password = sha1($this->input->post('password'));
		
		$username = $this->input->post('username');

		$this->db->where('username', $username);
		$result = $this->db->get('applicant');
		$rows 	= $result->num_rows();

		if($rows==0){
			$data = array(
				'firstname' 	=> $this->input->post('firstname'),
				'lastname' 		=> $this->input->post('lastname'),
				'housenum' 		=> $this->input->post('housenum'),
				'streetname'	=> $this->input->post('streetname'),
				'postcode' 		=> $this->input->post('postcode'),
				'email' 		=> $this->input->post('email'),
				'phonenumber' 	=> $this->input->post ('telephone'),
				'disabilities' 	=> $this->input->post('disabilities'),
				'addinfo' 		=> $this->input->post('addinfo'),
				'username' 		=> $username,
				'password' 		=> $enc_password
				);

		$insert= $this->db->insert('applicant',$data);
		return $insert;
		}else{
			$this->session->set_flashdata('regfail', 'Registeration failed, username exists, please use a different username!');
			redirect('home/index');
		}
	}

	public function login_user($username, $password){
			$this->db->select('applicant_id');
			$this->db->where('username', $this->input->post('username'));
			$this->db->where('password', sha1($this->input->post('password')));
			$query = $this->db->get('applicant');
			$result = $query->row();
			if($query->num_rows()==1){
				return $result->applicant_id;
			}else{
				return false;
			}
	}

	public function login_staff($username, $password){
		/*
			Equivalent to :
			$result = $mysqli->query("SELECT staff_id FROM staff WHERE username = username and password = sha1($this->input->post('password')");
			//RETURN ROW COUNT
			$row_count = $result->num_rows;

		*/
		$this->db->select('staff_id');
		$this->db->where('username', $this->input->post('username'));
		$this->db->where('password', sha1($this->input->post('password')));
		$query = $this->db->get('staff');
		$result = $query->row();
		if($query->num_rows()==1){
			return $result->staff_id;
		}else{
			return false;
		}
	}

	public function get_staff_type(){
		$this->db->select('staff_type_id');
		$this->db->where('username', $this->input->post('username'));
		$this->db->where('password', sha1($this->input->post('password')));
		$query = $this->db->get('staff');
		$result = $query->row();
		if($query->num_rows()==1){
			return $result->staff_type_id;

		}else{
			return false;
		}
	}

	public function addEnglish($grade){
		$english = $grade;
		$id = $this->session->userdata('user_id');

		$this->db->where('applicant_id', $id);
		$this->db->where('qualificat_id', 1);
		$query = $this->db->get('app_qual');
		if($query->num_rows() == 1){

				$data = array(
					  		'grade' => $english);
				$this->db->where('applicant_id', $id);
				$this->db->where('qualificat_id', 1);
				$update = $this->db->update('app_qual', $data);
			return $update;
		}else{
			$data = array('applicant_id' => $id,
					  'qualificat_id' => 1,
					  'grade' => $english);

			$insert = $this->db->insert('app_qual', $data);

			return $insert;
		}

	}

	public function addMaths($grade){
		$maths = $grade;
		$id = $this->session->userdata('user_id');
		$this->db->where('applicant_id', $id);
		$this->db->where('qualificat_id', 2);
		$query = $this->db->get('app_qual');
		if($query->num_rows() == 1){
				$data = array(
						  'grade' => $maths);
				$this->db->where('applicant_id', $id);
				$this->db->where('qualificat_id', 2);
				$update = $this->db->update('app_qual', $data);
				return $update;
		}else{
			$data = array('applicant_id' => $id,
					  'qualificat_id' => 2,
					  'grade' => $maths);
			$insert = $this->db->insert('app_qual', $data);

			return $insert;
		}
	}
	public function addICT($grade){
		$ICT = $grade;
		$id = $this->session->userdata('user_id');
		$this->db->where('applicant_id', $id);
		$this->db->where('qualificat_id', 4);
		$query = $this->db->get('app_qual');
		if($query->num_rows() == 1){
			$data = array(
						  'grade' => $ICT);
				$this->db->where('applicant_id', $id);
				$this->db->where('qualificat_id', 4);
				$update = $this->db->update('app_qual', $data);
				return $update;
		}else{
			$data = array('applicant_id' => $id,
					  'qualificat_id' => 4,
					  'grade' => $ICT);
			$insert = $this->db->insert('app_qual', $data);

			return $insert;
		}

	}

	public function addScience($grade){
		$science = $grade;
		$id = $this->session->userdata('user_id');
		$this->db->where('applicant_id', $id);
		$this->db->where('qualificat_id', 3);
		$query = $this->db->get('app_qual');
		if($query->num_rows() == 1){
				$data = array(
					  'grade' => $science);
			$this->db->where('applicant_id', $id);
			$this->db->where('qualificat_id', 3);
			$update = $this->db->update('app_qual', $data);
			return $update;
		}
			$data = array('applicant_id' => $id,
					  'qualificat_id' => 3,
					  'grade' => $science);
			$insert = $this->db->insert('app_qual', $data);

		return $insert;
	}


	public function createApplication(){
		$this->db->select('invite_count');
		$this->db->where('applicant_id', $this->session->userdata('user_id'));
		$query = $this->db->get('application');
		$result = $query->row();
		if($query->num_rows() == 1){
			if($result->invite_count < 3){
				$count = $result->invite_count;
				$new_count = $count + 1;
				$data = array(
			     		'place_offered'=> '',
			     		'invite_count' => $new_count
				);
				$this->db->where('applicant_id', $this->session->userdata('user_id'));
				$update = $this->db->update('application', $data);
				return $update;
			}else{
				return false;
			}
		}else{
			$data = array('applicant_id' => $this->session->userdata('user_id'),
			     'place_offered'=> 'N',
			     'invite_count' => 0
			);
			$insert = $this->db->insert('application', $data);
			return $insert;
		}	
	}

	public function loadTasterDays(){
		$this->db->select('invite_count');
		$query = $this->db->get('application');
		$result = $query->row();
		$count = $result->invite_count;
		if($count < 3){
			$this->db->where('student_count <', '5');
			$query = $this->db->get('taster_day');
			if($query->num_rows()>0){
				return $query->result();
			}
		}else{
			return false;
		}
	}

	public function addApplicantToTasterDay($tasterId , $applicantId){
		$this->db->where('applicant_id', $applicantId);
		$this->db->where('attended', 'Y');
		$this->db->where('taster_id', $tasterId);
		$query = $this->db->get('invite');


		if($query->num_rows() == 0){
				$this->db->select('student_count');
				$this->db->where("taster_id", $tasterId);
				$query = $this->db->get('taster_day');
				$result= $query->row();
				$count = $result->student_count;
				$new_count = $count + 1;

				$updata = array('student_count' => $new_count);

				$this->db->where("taster_id", $tasterId);
				$update = $this->db->update('taster_day', $updata);
				$data = array('taster_id' => $tasterId,
					  'applicant_id' => $this->session->userdata('user_id'));

				$insert = $this->db->insert('invite', $data);
				return $insert;
		}else{
			return false;
		}


			
	}

	public function getTasterDay(){
		$this->db->where('student_count >', '0');
		$query = $this->db->get('taster_day');
		if($query->num_rows()>0){
			return $query->result();
		}
	}

	public function loadAttendees($id){
		$this->db->select('invite.taster_id');
		$this->db->select('applicant.applicant_id');
		$this->db->select('applicant.firstname');
		$this->db->select('applicant.lastname');
		$this->db->from('invite');
		$this->db->join('applicant','applicant.applicant_id = invite.applicant_id','inner');
		$this->db->where('taster_id', $id);
		$this->db->where('attended','');

		$query=$this->db->get();

		if($query->num_rows()>0){
			return $query->result();
		}

	}

	public function recordAsAttended($id){
		$data = array('attended'=>'Y', 'offered'=> 'N');
		$this->db->where('applicant_id', $id);
		$update = $this->db->update('invite',$data);
		if($update){
			$data = array('place_offered'=>'N');
			$this->db->where('applicant_id', $id);
			$update = $this->db->update('application',$data);
			return $update;
		}
		
	}

	public function attended_applicants(){
		$this->db->where('place_offered','N');
		$query2 = $this->db->get('application');
		if($query2->num_rows()>0){

		$this->db->select('invite.taster_id');
		$this->db->select('applicant.applicant_id');
		$this->db->select('applicant.firstname');
		$this->db->select('applicant.lastname');
		$this->db->from('invite');
		$this->db->join('applicant','applicant.applicant_id = invite.applicant_id','inner');
		$this->db->where('attended','Y');
		$this->db->where('offered', 'N');

		$query=$this->db->get();
			if($query->num_rows()>0){
				return $query->result();
			}
		}
	}

	public function offerPlaceAccept($id){
		$data = array('place_offered' => 'Y');
		$this->db->where('applicant_id', $id);
		$update = $this->db->update('application', $data);
		if($update){
			$data = array('offered' => 'Y');
			$this->db->where('applicant_id', $id);
			$update = $this->db->update('invite', $data);
		}
		return $update;
	}

	public function offerPlaceDecline($id){
		$data = array('place_offered' => 'D');
		$this->db->where('applicant_id', $id);
		$update = $this->db->update('application', $data);
		if($update){
			$data = array('offered' => '');
			$this->db->where('applicant_id', $id);
			$update = $this->db->update('invite', $data);
			return $update;
		}
		
	}

	public function check_if_offered($id){
		$this->db->where('applicant_id', $id);
		$this->db->where('decision','');
		$query0 = $this->db->get('application');
		if($query0->num_rows() == 1){


			$this->db->where('place_offered', 'Y');
			$this->db->where('applicant_id', $id);
			$query = $this->db->get('application');
			if($query->num_rows() == 1){
				return $query->result();
			}
			$this->db->where('place_offered', 'N');
			$this->db->where('applicant_id', $id);
			$query2 = $this->db->get('application');
			if($query2 -> num_rows() == 1){
				return $query2->result();
			}
			$this->db->where('place_offered', 'na');
			$this->db->where('applicant_id', $id);
			$query3 = $this->db->get('application');
			if($query3 -> num_rows() == 1){
				return $query3->result();
			}
		}
	}

	public function acceptPos($id){
		$data = array('decision' => 'Accepted');
		$this->db->where('applicant_id', $id);
		$update = $this->db->update('application', $data);
		return $update;
	}

	public function declinePos($id){
		$data = array('decision' => 'Declined');
		$this->db->where('applicant_id', $id);
		$update = $this->db->update('application', $data);
		return $update;
	}

	
}