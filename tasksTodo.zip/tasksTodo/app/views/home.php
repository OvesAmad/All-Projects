<?php if($this->session->flashdata('registered')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('registered');?></p>
        

<?php endif; ?>

<?php if($this->session->flashdata('success_login')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('success_login');?></p>
        

<?php endif; ?>

<?php if($this->session->flashdata('failed_login')) : ?>

<p class="alert alert-dismissable alert-danger"><?php echo $this->session->flashdata('failed_login');?></p>
        

<?php endif; ?>

<?php if($this->session->flashdata('logged_out')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('logged_out');?></p>
        

<?php endif; ?>

<?php if($this->session->flashdata('failed')) : ?>

<p class="alert alert-dismissable alert-danger"><?php echo $this->session->flashdata('failed');?></p>
        

<?php endif; ?>


<div class="jumbotron">
    <div class="container center">
        <h1 class="display-3">Welcome to tasksToDo!</h1>
        <p class="lead">This is a simple task management which lets you organise and create tasks which need to be completed!</p><br>
        
        <?php if($this->session->userdata('logged_in')) : ?>
                        <!-- Remove the element completely -->
        <?php else: ?>
            <form action="<?php echo base_url();?>users/register">
                <button class="btn btn-outline-primary " type="register" >Register NOW!</button>
            </form>
        <?php endif; ?>
    </div>
</div>