<div class = 'container reg-form'>
<h3>Register Now It's <strong>FREE!</strong></h3>
<p>Please fill in all your details to create an account on this awesome site!</p>

<!-- Display Errors at the top of the page -->
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>

<?php $attributes = array('id' => 'reg_form', 'class' => 'form_group');?>
<?php echo form_open('users/register', $attributes); ?>

<!-- The registration form itself -->

    <?php echo form_label('Firstname:'); ?>
    <?php
        //Firstname input
        $data = array('name' => 'firstName',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('firstName'));
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Lastname:'); ?>
    <?php
        //Lastname input
        $data = array('name' => 'lastName',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('lastName'));
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Email:'); ?>
    <?php
        //Email input
        $data = array('name' => 'email',
                      'type' => 'email',
                      'class' => 'form-control',
                      'value' => set_value('email'));
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Username:'); ?>
    <?php
        //Username input
        $data = array('name' => 'username',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('username'));
    ?>

    <?php echo form_input($data);?>
    
    <?php echo form_label('Password:'); ?>
    <?php
        //Password input
        $data = array('name' => 'password',
                      'type' => 'password',
                      'class' => 'form-control',
                      'value' => set_value('password'));
    ?>

    <?php echo form_password($data);?>

    <?php echo form_label('Confirm Password:'); ?>
    <?php
        //Confirm Password input
        $data = array('name' => 'password2',
                      'type' => 'password',
                      'class' => 'form-control',
                      'value' => set_value('password2'));
    ?>

    <?php echo form_password($data);?>

    <br>
    <?php
        //Submit button
        $data = array('name' => 'submit', 
                      'class' => 'btn btn-outline-primary my-2 my-sm-0 custButton', 
                      'type' => 'submit',
                      'value' => 'Submit');
    ?>

    <?php echo form_submit($data); ?>


<?php echo form_close(); ?> 
</div>