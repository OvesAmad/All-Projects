
<?php if($this->session->userdata('logged_in')) : ?>

    <!-- remember to put this in an external css -->

    <p style="margin-right:10px;">Hey there, <?php echo $this->session->userdata('username'); ?> </p>

    <?php $attributes = array('id' => 'logout_form', 'class' => 'form-inline my-2 my-lg-0');?>
    
    <?php echo form_open('users/logout', $attributes); ?>

        <?php
        //Logout button
        $data = array('name' => 'submit', 
                      'class' => 'btn btn-outline-primary my-2 my-sm-0', 
                      'type' => 'submit',
                      'value' => 'Logout');
    ?>
    <?php echo form_submit($data); ?>


    <?php echo form_close(); ?> 

<?php else : ?>

<?php $attributes = array('id' => 'login_form', 'class' => 'form-inline my-2 my-lg-0');?>

<?php echo form_open('users/login', $attributes); ?>

    <?php
        //Username input
        $data = array('name' => 'username', 
                      'class' => 'form-control mr-sm-2', 
                      'type' => 'text', 
                      'placeholder' => 'Enter Username', 
                      'value' => set_value('username'));
    ?>

    <?php echo form_input($data);?>

    <?php
        //Password input
        $data = array('name' => 'password', 
                      'class' => 'form-control mr-sm-2', 
                      'type' => 'password', 
                      'placeholder' => 'Enter Password', 
                      'value' => set_value('password'));
    ?>

    <?php echo form_password($data); ?>

    <?php
        //Submit button
        $data = array('name' => 'submit', 
                      'class' => 'btn btn-outline-primary my-2 my-sm-0', 
                      'type' => 'submit',
                      'value' => 'Login');
    ?>

    <?php echo form_submit($data); ?>


<?php echo form_close(); ?> 


<?php endif; ?>



