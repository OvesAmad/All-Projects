<div class="container">
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>

<?php $attributes = array('id' => 'create_cat_form', 'class' => 'form_group');?>
<?php echo form_open('categories/create', $attributes); ?>

<!-- The registration form itself -->

    <?php echo form_label('Category Name:'); ?>
    <?php
        //Category Name input
        $data = array('name' => 'catName',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('catName'));
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Category Description:'); ?>
    <?php
        //Category Description input
        $data = array('name' => 'catDescription',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('catName'));
    ?>

    <?php echo form_textarea($data);?>
    
        <?php
        //Submit button
        $data = array('name' => 'submit', 
                      'class' => 'btn btn-outline-primary my-2 my-sm-0 custButton', 
                      'type' => 'submit',
                      'value' => 'Add Category');
    ?>

    <?php echo form_submit($data); ?>
    
    <?php echo form_close(); ?>
    </div>