<div class="container">
<?php if($this->session->flashdata('task_created')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('task_created');?></p>
        

<?php endif; ?>
    
<?php if($this->session->flashdata('task_deleted')) : ?>

<p class="alert alert-dismissable alert-danger"><?php echo $this->session->flashdata('task_deleted');?></p>
<?php endif; ?>
    
<?php if($this->session->flashdata('task_updated')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('task_updated');?></p>
        

<?php endif; ?>
    
<?php if($this->session->flashdata('marked_completed')) : ?>

<p class="alert alert-dismissable alert-sucess"><?php echo $this->session->flashdata('marked_completed');?></p>
        

<?php endif; ?>
    
<?php if($this->session->flashdata('marked_new')) : ?>

<p class="alert alert-dismissable alert-sucess"><?php echo $this->session->flashdata('marked_new');?></p>
        

<?php endif; ?>
    <h4>Category Actions</h4>
<ul id='actions'>
    
    
    <li><a href="<?php echo base_url(); ?>tasks/add/<?php echo $cat->id;?>">Add Task</a></li>
    <li><a href="<?php echo base_url(); ?>categories/edit/<?php echo $cat->id; ?>">Edit Category</a></li>
    <li><a onclick="return confirm('Are you sure?')" href="<?php echo base_url(); ?>categories/delete/<?php echo $cat->id;?>">Delete Category</a></li>
    
</ul>
<hr>

    <h4><?php echo $cat->catName ?></h4>
    <small>Created On: <?php echo date("n-j-Y", strtotime($cat->dateCreated));?></small>
    <br><br>
    <p><?php echo $cat->catDescription; ?></p>
    
    <h4>Active tasks</h4>
    
    <?php if($active_tasks) : ?>
        <ul>
            <?php foreach($active_tasks as $tasks) :?>
            <li><a href="<?php echo base_url(); ?>tasks/show/<?php echo $tasks->taskId;?>"><?php echo $tasks->taskName;?></a></li>
            <?php endforeach;?>
        </ul>
    <?php else : ?>
        <p> There are no active tasks</p>
    <?php endif ; ?>
    <br>
    
    
        <h4>Completed tasks</h4>
    
    <?php if($inactive_tasks) : ?>
        <ul>
            <?php foreach($inactive_tasks as $tasks) :?>
            <li><a href="<?php echo base_url(); ?>tasks/show/<?php echo $tasks->taskId;?>"><?php echo $tasks->taskName;?></a></li>
            <?php endforeach;?>
        </ul>
    <?php else : ?>
        <p> There are no comepleted tasks</p>
    <?php endif ; ?>
    <br>
    
    
    
    
    
</div>