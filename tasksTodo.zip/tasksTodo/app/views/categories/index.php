<div class="container">
    
<?php if($this->session->flashdata('category_created')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('category_created');?></p>
        
<?php endif; ?>
    
<?php if($this->session->flashdata('category_updated')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('category_updated');?></p>
        
<?php endif; ?>
    
<?php if($this->session->flashdata('category_deleted')) : ?>

<p class="alert alert-dismissable alert-success"><?php echo $this->session->flashdata('category_deleted');?></p>
        
<?php endif; ?>

<h1>My Current Categories</h1>

<ul>
<?php foreach($cats as $cat) : ?>

    <!-- Turn this in to a table -->
    
    <p><strong><a href="<?php echo base_url(); ?>categories/show/<?php echo $cat->id; ?>"><?php echo $cat->catName;?></a></strong></p>
    <p><small><?php echo $cat->catDescription;?></small></p>

<?php endforeach ; ?>

</ul>
<a href="<?php echo base_url(); ?>categories/create">Create New Category.</a>






</div>




