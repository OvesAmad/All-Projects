<!-- Display Errors at the top of the page -->
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>

<?php $attributes = array('id' => 'add_task_form', 'class' => 'form_group');?>
<?php echo form_open('tasks/add/'.$this->uri->segment(3).'', $attributes); ?>

<!-- The registration form itself -->

    <?php echo form_label('Task Name:'); ?>
    <?php
        //Firstname input
        $data = array('name' => 'taskName',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('taskName'));
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Task Description:'); ?>
    <?php
        //Lastname input
        $data = array('name' => 'taskDesc',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => set_value('taskDesc'));
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Due Date:'); ?>
    <input type="date" name="dueDate" />

    <?php $data = array("value" => "Add Task",
                    "name" => "submit",
                    "class" => "btn btn-primary-outline"); ?>

    <?php echo form_submit($data);?>

<?php echo form_close(); ?>