<h1>Edit Task</h1>

<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>

<?php $attributes = array('id' => 'edit_task_form', 'class' => 'form_group');?>

<?php echo form_open('tasks/edit/'.$this->uri->segment(3).'', $attributes); ?>

<?php echo form_label('Task Name:'); ?>
    <?php
        //Taskname input
        $data = array('name' => 'taskName',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => $curr_task->taskName);
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Task Description:'); ?>
    <?php
        //Lastname input
        $data = array('name' => 'taskDesc',
                      'type' => 'text',
                      'class' => 'form-control',
                      'value' => $curr_task->taskDesc);
    ?>

    <?php echo form_input($data);?>

    <?php echo form_label('Due Date:'); ?>
    <input type="date" name="dueDate" value="<?php echo $curr_task->dueDate; ?>"/>

    <?php $data = array("value" => "Edit Task",
                    "name" => "submit",
                    "class" => "btn btn-primary-outline"); ?>

    <?php echo form_submit($data);?>

<?php echo form_close(); ?>