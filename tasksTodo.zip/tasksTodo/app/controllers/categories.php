<?php

class Categories extends CI_Controller{
    //Create constructor in order to not let anyone access this page without login
    
    public function __construct(){
        parent::__construct();
        
        if(!$this->session->userdata('logged_in')){
            $this->session->set_flashdata('failed', 'Oops, you do not have access to this page... Sorry.');
            redirect('home/index');
        }
    }
    
    public function index(){
        $u_id = $this->session->userdata('user_id');
        
        
        $data['cats'] = $this->Cat_model->get_cats();
        
        
        
        
        //Load view and layout for this controller
        $data['main_content'] = 'categories/index';
        $this->load->view('layouts/main', $data);
        
        
    }
    
    public function show($cat_id){
        
        $data['cat'] = $this->Cat_model->get_cat($cat_id);
        
        $data['active_tasks'] = $this->Cat_model->get_cat_tasks($cat_id,true);
        
        $data['inactive_tasks'] = $this->Cat_model->get_cat_tasks($cat_id,false);
        
        $data['main_content'] = 'categories/show';
        $this->load->view('layouts/main', $data);
        
    }
    
    public function create(){
        $this->form_validation->set_rules('catName','Category Name','trim|required|xss_clean');
        $this->form_validation->set_rules('catDescription','Category Description','trim|xss_clean');
        
        if($this->form_validation->run() == false){
            $data['main_content'] = 'categories/add_cat';
            $this->load->view('layouts/main',$data);
        }else{
            $data = array(
                    'catName' => $this->input->post('catName'),
                    'catDescription' => $this->input->post('catDescription'),
                    'userId' => $this->session->userdata('user_id')
            );
            
            if($this->Cat_model->create_category($data)){
                $this->session->set_flashdata('category_created', 'Your task category has successfully been created.');
                redirect('categories/index');
            }
        }
        
    }
    
    public function edit($id){
        $this->form_validation->set_rules('catName','Category Name','trim|required|xss_clean');
        $this->form_validation->set_rules('catDescription','Category Description','trim|xss_clean');
        
        if($this->form_validation->run() == false){
            
            $data['this_cat'] = $this->Cat_model->get_cat_data($id);
            
            $data['main_content'] = 'categories/edit_cat';
            $this->load->view('layouts/main',$data);
        }else{
            $data = array(
                    'catName' => $this->input->post('catName'),
                    'catDescription' => $this->input->post('catDescription'),
                    'userId' => $this->session->userdata('user_id')
            );
            
            if($this->Cat_model->edit_category($id,$data)){
                $this->session->set_flashdata('category_updated', 'Your task category has successfully been updated.');
                redirect('categories/index');
            }
        }
    }
    
    public function delete($id){
        $this->Cat_model->delete_cat($id);
        
        $this->session->set_flashdata('category_deleted','Your task category has successfully been deleted');
        
        redirect('categories/index');
    }
    
}


?>