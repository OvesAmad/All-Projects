<?php

class Tasks extends CI_controller{
    public function show($id){
        $data['task'] = $this->Task_model->get_task($id);
        
        $data['is_complete'] = $this->Task_model->check_if_complete($id);
        
        $data['main_content'] = 'tasks/show';
        $this->load->view('layouts/main', $data);
    
    }
    
    public function add($cat_id = null){
        $this->form_validation->set_rules('taskName', 'Task Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('taskDesc', 'Task Description', 'trim|xss_clean');
        
        
        
        if($this->form_validation->run() == false){
            $data['cat_name'] = $this->Task_model->get_cat_name($cat_id);
        
            $data['main_content'] = 'tasks/add_task';
        
            $this->load->view('layouts/main', $data);
        }else{
            $data = array(
                    'taskName' => $this->input->post('taskName'),
                    'taskDesc' => $this->input->post('taskDesc'),
                    'dueDate' => $this->input->post('dueDate'),
                    'catId' => $cat_id
            );
            if($this->Task_model->create_task($data)){
                $this->session->set_flashdata('task_created','Your task has been created');
                redirect('categories/show/'.$cat_id);
            }
        }
        
    }
    public function edit($task_id){
        $this->form_validation->set_rules('taskName', 'Task Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('taskDesc', 'Task Description', 'trim|xss_clean');
        
        if($this->form_validation->run() == false){
            $data['cat_id'] = $this->Task_model->get_task_cat_id($task_id);
            
            $data['cat_name'] = $this->Task_model->get_cat_name($data['cat_id']);
            
            $data['curr_task'] = $this->Task_model->get_task_data($task_id);
            
            $data['main_content'] = 'tasks/edit_task';
            
            $this->load->view('layouts/main', $data);
        }else{
            $cat_id = $this->Task_model->get_task_cat_id($task_id);
            
            $data = array(
                'taskName' => $this->input->post('taskName'),
                'taskDesc' => $this->input->post('taskDesc'),
                'dueDate' => $this->input->post('dueDate'),
                'catId' => $cat_id
            );
            
            if($this->Task_model->edit_task($task_id, $data)){
                $this->session->set_flashdata('task_updated', 'Your task has been updated');
                
                redirect('categories/show/'.$cat_id.'');
            }
        }
    }
    
    public function delete($cat_id,$id){
        $this->Task_model->delete($task_id);
        
        $this->session->set_flashdata('task_deleted','Your task has been deleted');
        
        redirect('categories/show/'.$cat_id.'');
    }
    
    public function mark_complete($task_id){
        if($this->Task_model->mark_complete($task_id)){
            $cat_id = $this->Task_model->get_task_cat_id($task_id);
            $this->session->set_flashdata('marked_completed','Task marked complete.');
            redirect('categories/show/'.$cat_id.'');
        }
    }
    
    public function mark_new($task_id){
        if($this->Task_model->mark_new($task_id)){
            $cat_id = $this->Task_model->get_task_cat_id($task_id);
            $this->session->set_flashdata('marked_new','Task marked new.');
            redirect('categories/show/'.$cat_id.'');
        }
    }

}

?>