<?php

class Users extends CI_Controller{
    public function register(){
        //Validating all the data in the registration form using built in codeIgniter function
        $this->form_validation->set_rules('firstName','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');
        
        $this->form_validation->set_rules('lastName','Last Name','trim|required|max_length[50]|min_length[2]|xss_clean');
        
        $this->form_validation->set_rules('email','email','trim|required|max_length[100]|min_length[5]|xss_clean|valid_email');
        
        $this->form_validation->set_rules('username','Username','trim|required|max_length[25]|min_length[6]|xss_clean');
        
        $this->form_validation->set_rules('password','Password','trim|required|max_length[50]|min_length[8]|xss_clean');
        
        $this->form_validation->set_rules('password2','Confirm Password','trim|required|max_length[50]|min_length[8]|xss_clean|matches[password]');
        
        //Check if the form has been submitted now
        if($this->form_validation->run() == false){
            $data['main_content'] = 'users/register';
            $this->load->view('layouts/main', $data);
        }else{
            if($this->User_model->create_user()){
                $this->session->set_flashdata('registered','You are now officially a member of this website. Yay!');
                redirect('home');
            }
        }
        
        
    }
    
    public function login(){
        
        $this->form_validation->set_rules('username','Username','trim|required|min_length[6]|xss_clean');
        
        $this->form_validation->set_rules('password','Password','trim|required|min_length[8]|xss_clean');
        
        if($this->form_validation->run() == false){
            //Do not so anything
        }else{
            //If the form validation is run do the following
            
            //Get the user name and password
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            
            //Get the user id from the database by running the following function
            $u_id = $this->User_model->login_user($username, $password);
            
            //Validate the user and set up a session
            if($u_id){
                $u_data = array(
                            'user_id'   => $u_id,
                            'username'  => $username,
                            'logged_in' => true
                            );
                
                //Create the session using the $u_data array
                $this->session->set_userdata($u_data);
                
                $this->session->set_flashdata('success_login', 'Yay! You have been logged in.');
                
                //redirect the user back to home page
                redirect('home/index');
            }else{
                
                //If the validation fails do the following:
                //respond with a error message
                $this->session->set_flashdata('failed_login', 'Sorry, the login info that you entered is invalid, please try again.');
                redirect('home/index');
                
            }
        }
        
    }
    
    public function logout(){
        //Unset all session data
        $this->session->unset_userdata('logged_in');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        //send a message to the user
        $this->session->set_flashdata('logged_out', 'You have sucessfully logged out.');
        redirect('home/index');
        //redirect the user back to home page
        $this->session->sess_destroy();
        
        
        
                
        
        
        
    }
    
    
    
}
?>