<?php
class Cat_model extends CI_Model{
    public function get_cats(){
        
        $this->db->where('userId', $this->session->userdata('user_id'));
        
        $get_cats_query = $this->db->get('categories');
        
        return $get_cats_query->result();
    }
    
    public function get_cat($id){
        $this->db->select('*');
        $this->db->from('categories');
        $this->db->where('id',$id);
        $get_cat_query = $this->db->get();    
        
        if($get_cat_query->num_rows() != 1){
            return false;
        }else{
            return $get_cat_query->row();
        }
    
    }
    
    public function create_category($data){
        $insert_cat = $this->db->insert('categories',$data);
        
        return $insert_cat;
    }
    
    public function edit_category($id, $data){
        $this->db->where('id', $id);
        $this->db->update('categories',$data);
        
        return TRUE;
    }
    
    public function get_cat_data($id){
        $this->db->where('id',$id);
        $get_query = $this->db->get('categories');
        return $get_query->row();
    }
    
    public function delete_cat($id){
        $this->db->where('id',$id);
        $this->db->delete('categories');
        
        return TRUE;
    }
    
    public function get_cat_tasks($cat_id,$active = true){
        $this->db->select('
                    tasks.taskName,
                    tasks.taskDesc,
                    tasks.id as taskId,
                    categories.catName,
                    categories.catDescription
                    
        ');
        $this->db->from('tasks');
        $this->db->join('categories','categories.id = tasks.catId');
        $this->db->where('tasks.catId', $cat_id);
        if($active == true){
            $this->db->where('tasks.isComplete', 0);
        }else{
            $this->db->where('tasks.isComplete', 1);
        }
        $get_query = $this->db->get();
        
        
        if($get_query->num_rows() < 1){
            return false;
        }
        
        return $get_query->result();
    }
}