<?php

class User_model extends CI_Model{
    public function create_user(){
        //Use input helper instead of super global $_POST example $_POST[firstName];
        
        //Encrypt the password at the moment using just hashing
        /*$encrypted_password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);*/
        
        $encrypted_password = sha1($this->input->post('password'));
        
        
        
        //Store given data in this array
        $data = array(
                    'firstName' => $this->input->post('firstName'),
                    'lastName'  => $this->input->post('lastName'),
                    'email'     => $this->input->post('email'),
                    'username'  => $this->input->post('username'),
                    'password'  => $encrypted_password
                );
        
        
        //Use active record class given by CodeIgniter instead of log querys - saves time
        $insert_query = $this->db->insert('users', $data);
        return $insert_query;
        
        
    }
    
    public function login_user($username, $password){
        
        //first encrypt the entered password for comparisson
        $passed_enc_password = sha1($password);
        
        //Compare with data stored in the database
        $this->db->where('username', $username);
        $this->db->where('password', $passed_enc_password);
        
        $result = $this->db->get('users');
        
        if($result->num_rows() == 1){
            return $result->row(0)->id;
        }else{
            return false;
        }
        
        
        
        
    
    }
    
    
    
    
}

?>