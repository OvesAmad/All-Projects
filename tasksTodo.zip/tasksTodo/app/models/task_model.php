<?php

class Task_model extends CI_model{
    public function get_task($id){
        
        $this->db->select('
                tasks.taskName,
                tasks.id,
                tasks.createDate,
                tasks.dueDate,
                tasks.taskDesc,
                tasks.isComplete,
                categories.id as catId,
                categories.catName,
                categories.catDescription
        ');
        
        $this->db->from('tasks');
        $this->db->join('categories', 'categories.id = tasks.catId');
        $this->db->where('tasks.id', $id);
        $get_query = $this->db->get();
        if($get_query->num_rows() != 1){
            return false;
        }else{
            return $get_query->row();
        }
    }
    
    public function check_if_complete($id){
        $this->db->where('id', $id);
        $get_query = $this->db->get('tasks');
        return $get_query->row()->isComplete;
    }
    
    public function get_cat_name($cat_id){
        $this->db->where('id',$cat_id);
        $query = $this->db->get('categories');
        return $query->row()->catName;
    }
    
    public function create_task($data){
	   $insert = $this->db->insert('tasks', $data);
	   return $insert;
    }
    
    public function get_task_cat_id($task_id){
        $this->db->where('id', $task_id);
        $query = $this->db->get('tasks');
        return $query->row()->catId;
    }
    
    
    public function get_task_data($task_id){
        $this->db->where('id', $task_id);
        $query = $this->db->get('tasks');
        return $query->row();
    }
    
    public function edit_task($task_id, $data){
        $this->db->where('id',$task_id);
        $this->db->update('tasks',$data);
        return TRUE;
    }
    
    public function delete($task_id){
        $this->db->where('id', $task_id);
        $this->db->delete('tasks');
        return;
    }
    
    public function mark_new($task_id){
        $this->db->set('isComplete',0);
        $this->db->where('id', $task_id);
        $this->db->update('tasks');
        return true;
    }
    public function mark_complete($task_id){
        $this->db->set('isComplete',1);
        $this->db->where('id', $task_id);
        $this->db->update('tasks');
        return true;
    }
    
}

?>